﻿using UnityEngine;
using System.Collections;

public class Crack : MonoBehaviour
{
    public Collider[] colliders;
    public float Mass = 1;
    public float Drag = 2;
    public float time = 1;

    void Awake()
    {
        colliders = gameObject.GetComponentsInChildren<Collider>();
        foreach (Collider item in colliders)
        {
            item.attachedRigidbody.constraints = RigidbodyConstraints.FreezeAll;
            item.attachedRigidbody.mass = Mass;
            item.attachedRigidbody.drag = Drag;
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.tag == "Player")
        {
            if (time > 0)
            {
                time -= Time.deltaTime;
                if (time < 0)
                {
                    colliders = gameObject.GetComponentsInChildren<Collider>();
                    foreach (Collider item in colliders)
                    {
                        item.attachedRigidbody.constraints = RigidbodyConstraints.None;
                        Destroy(gameObject, 2);
                    }
                }
            }
        }
    }
}