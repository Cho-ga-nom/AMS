﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crack_Sound : MonoBehaviour
{
    public AudioSource musicPlayer;
    public AudioClip EffectMusic;

    void Start()
    {
        musicPlayer = GetComponent<AudioSource>();
    }

    public static void playSound_1(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Play();
    }

    public static void playSound_2(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Pause();
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.tag == "Player")
            playSound_1(EffectMusic, musicPlayer);
    }

    private void OnTriggerExit(Collider other)
    {
        playSound_2(EffectMusic, musicPlayer);
    }
}
