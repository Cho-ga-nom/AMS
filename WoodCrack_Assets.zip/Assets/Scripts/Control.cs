﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Control : MonoBehaviour
{
    private Rigidbody newrigidbody;

    void Start()
    {
        newrigidbody = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        Vector3 speed = new Vector3();

        if (Input.GetKey(KeyCode.LeftArrow))
            speed.x -= 6f;
        if (Input.GetKey(KeyCode.RightArrow))
            speed.x += 6f;
        if (Input.GetKey(KeyCode.UpArrow))
            speed.z += 6f;
        if (Input.GetKey(KeyCode.DownArrow))
            speed.z -= 6f;

        newrigidbody.velocity = Vector3.Lerp(newrigidbody.velocity, speed, 2f * Time.deltaTime);
    }
}