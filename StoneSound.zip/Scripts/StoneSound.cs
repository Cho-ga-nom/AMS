﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneSound : MonoBehaviour
{
    public AudioSource musicPlayer;
    public AudioClip EffectMusic;
    public AudioClip SpaceBarMusic;

    void Start()
    {
        musicPlayer = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            playSound_2(SpaceBarMusic, musicPlayer);
    }

    public static void playSound_1(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Play();
    }

    public static void playSound_2(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Play();
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
            playSound_1(EffectMusic, musicPlayer);
    }
}
