﻿/**********************
 * 프로그램명 : IceFloor_Crack.cs
 * 작성자 : 조수현 (나선율, 김택원, 김민선, 이승연)
 * 작성일 : 2019년 11월 21일
 * 프로그램 설명 : 살얼음판 내부에 진입해서 일정시간 이상 머물러 있으면 얼음판이 깨짐.
                   살얼음판 내부에 서있는 동안 얼음에 금이 가는 소리가 남.
 **********************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crack : MonoBehaviour
{
    public Collider[] colliders;
    public float Mass = 1;
    public float Drag = 3;
    public float time = 2;
    public AudioSource musicPlayer;
    public AudioClip EffectMusic;

    void Start()
    {
        musicPlayer = GetComponent<AudioSource>();
    }

    public static void playSound(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Play();
    }

    void Awake()
    {
        colliders = gameObject.GetComponentsInChildren<Collider>();
        foreach(Collider item in colliders)
        {
            item.attachedRigidbody.constraints = (RigidbodyConstraints)126;
            item.attachedRigidbody.mass = Mass;
            item.attachedRigidbody.drag = Drag;
        }
    }

    void OnTriggerStay(Collider col)
    {
        if (col.tag == "Player")
        {
            if(time > 0)
            {
                time -= Time.deltaTime;
                if(time < 0)
                {
                    colliders = gameObject.GetComponentsInChildren<Collider>();
                    foreach (Collider item in colliders)
                    {
                        item.attachedRigidbody.constraints = (RigidbodyConstraints)0;
                        playSound(EffectMusic, musicPlayer);
                        Destroy(gameObject, 2);
                    }
                }
            }
        }
    }
}