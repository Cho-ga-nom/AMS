﻿/*********************
 * 프로그램명 : IceFloor_CrackSound.cs
 * 작성자 : 조수현 (나선율, 김택원, 김민선, 이승연)
 * 작성일 : 2019년 11월 21일
 * 프로그램 설명 : 플레이어가 살얼음판 바깥 부분을 지나면 얼음에 금이 가는 소리를 발생.
 * ******************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crack_Sound : MonoBehaviour
{
    public AudioSource musicPlayer;
    public AudioClip EffectMusic;

    void Start()
    {
        musicPlayer = GetComponent<AudioSource>();
    }

    public static void playSound_1(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Play();
    }

    public static void playSound_2(AudioClip clip, AudioSource audioPlayer)
    {
        audioPlayer.clip = clip;
        audioPlayer.Pause();
    }

    void OnTriggerEnter(Collider col)
    {
        if(col.tag == "Player")
            playSound_1(EffectMusic, musicPlayer);
    }

    void OnTriggerExit(Collider other)
    {
        playSound_2(EffectMusic, musicPlayer);
    }
}
